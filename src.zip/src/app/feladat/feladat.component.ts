import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrls: ['./feladat.component.css']
})
export class FeladatComponent {


  ertekelniKivantSzam:number=1;

  eredmeny:string="";

  PrimeE():void{
     let oszto:number=0;
     for(let i:number=0; i<this.ertekelniKivantSzam; i++){
      if(this.ertekelniKivantSzam%i==0){
        oszto++;
      }
     }
     if(oszto==2){
     this.eredmeny="prím"
    }
    else{
      this.eredmeny="NEM prím"
    }

  }

  eredmenyek:string[]=[];

  EredmenyMentes():void{
    this.eredmenyek.push(`Az ${this.ertekelniKivantSzam} ${this.eredmeny}`);

  }

}
