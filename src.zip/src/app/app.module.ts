import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FeladatComponent } from './feladat/feladat.component';
import { FormControl } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    FeladatComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormControl
  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
